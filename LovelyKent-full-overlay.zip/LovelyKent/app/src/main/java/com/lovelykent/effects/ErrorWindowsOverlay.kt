package com.lovelykent.effects

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min

/** Ten playful, in-app retro error windows. It never blocks Android navigation. */
class ErrorWindowsOverlay(context: Context, private val onAllClosed: () -> Unit) : FrameLayout(context) {
    private val handler = android.os.Handler(android.os.Looper.getMainLooper())
    private val cards = mutableListOf<View>()
    private var shown = 0
    private var closed = 0
    private var started = false
    private val finishLabel = TextView(context).apply {
        text = "ТЕПЕРЬ ТЫ МОЙ ❤️"
        setTextColor(Color.WHITE)
        textSize = 27f
        typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        gravity = Gravity.CENTER
        alpha = 0f
        visibility = GONE
        contentDescription = "ТЕПЕРЬ ТЫ МОЙ"
    }

    init {
        setBackgroundColor(0xD9000000.toInt())
        clipChildren = false
        clipToPadding = false
        isFocusable = false
        isClickable = false
        addView(finishLabel, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_YES
        contentDescription = "Розыгрыш: окна ошибок LovelyKent"
    }

    fun start() {
        if (shown >= 10) return
        started = true
        handler.removeCallbacks(spawn)
        handler.postDelayed(spawn, 350L)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        cards.forEach { it.animate().cancel() }
    }

    private val spawn = object : Runnable {
        override fun run() {
            if (shown >= 10) return
            addErrorWindow(shown)
            shown++
            if (shown < 10) handler.postDelayed(this, (650L - shown * 48L).coerceAtLeast(180L))
        }
    }

    private fun addErrorWindow(index: Int) {
        val card = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(0xFFE0E0E0.toInt(), 2)
            elevation = dp(8 + index % 3 * 2).toFloat()
            clipToOutline = true
            isFocusable = true
            contentDescription = "Окно ошибки ${index + 1} из 10"
        }
        val titleBar = TextView(context).apply {
            text = "LovelyKent.exe — System Error"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(9), 0, dp(5), 0)
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(0xFF0A246A.toInt(), 0xFF3A6EA5.toInt()))
            maxLines = 1
            isSingleLine = true
        }
        card.addView(titleBar, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, dp(30)))

        val body = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(8), dp(3))
        }
        val errorIcon = TextView(context).apply {
            text = "×"
            textSize = 31f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFC90016.toInt())
                setStroke(dp(2), 0xFF8E0010.toInt())
            }
            contentDescription = "Ошибка"
        }
        body.addView(errorIcon, LinearLayout.LayoutParams(dp(40), dp(40)))
        val message = TextView(context).apply {
            text = "ЛЮБИ МЕНЯ"
            setTextColor(Color.BLACK)
            textSize = 19f
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(6), 0, dp(2), 0)
        }
        body.addView(message, LinearLayout.LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        card.addView(body, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, 0, 1f))

        val buttonRow = LinearLayout(context).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, dp(10), dp(8))
        }
        val love = Button(context).apply {
            text = "ЛЮБЛЮ ТЕБЯ"
            textSize = 11f
            isAllCaps = false
            minHeight = dp(40)
            minWidth = dp(120)
            setPadding(dp(10), 0, dp(10), 0)
            setTextColor(Color.BLACK)
            background = rounded(0xFFF0F0F0.toInt(), 2).also { it.setStroke(dp(1), 0xFF777777.toInt()) }
            contentDescription = "Закрыть окно ${index + 1}: Люблю тебя"
            setOnClickListener {
                isEnabled = false
                if (card.parent != null) {
                    card.animate().cancel()
                    card.animate().alpha(0f).scaleX(0.82f).scaleY(0.82f).setDuration(170L).withEndAction {
                        removeView(card)
                        closed++
                        if (closed == 10) showFinalMessage()
                    }.start()
                }
            }
        }
        buttonRow.addView(love)
        card.addView(buttonRow, LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT))

        cards.add(card)
        addView(card)
        card.measure(View.MeasureSpec.makeMeasureSpec(width.coerceAtLeast(dp(280)), View.MeasureSpec.AT_MOST), View.MeasureSpec.makeMeasureSpec(height.coerceAtLeast(dp(150)), View.MeasureSpec.AT_MOST))
        val cardW = min(width - dp(20), max(dp(260), card.measuredWidth))
        val cardH = max(dp(142), card.measuredHeight)
        val usableW = max(dp(1), width - cardW - dp(12))
        val usableH = max(dp(1), height - cardH - dp(16))
        val xRatios = floatArrayOf(.02f, .35f, .13f, .48f, .04f, .40f, .20f, .50f, .08f, .30f)
        val yRatios = floatArrayOf(.08f, .17f, .31f, .04f, .48f, .40f, .61f, .57f, .72f, .78f)
        val x = (usableW * xRatios[index]).toInt().coerceIn(0, usableW)
        val y = (usableH * yRatios[index]).toInt().coerceIn(0, usableH)
        val lp = LayoutParams(cardW, cardH, Gravity.TOP or Gravity.START)
        lp.leftMargin = x
        lp.topMargin = y
        card.layoutParams = lp
        card.alpha = 0f
        card.scaleX = 0.72f
        card.scaleY = 0.72f
        card.rotation = if (index % 2 == 0) -0.6f else 0.6f
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(240L).start()
        if (index % 3 == 1) {
            card.translationX = dp(3).toFloat()
            card.animate().translationX(0f).setDuration(120L).start()
        }
        sendAccessibilityEvent(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
    }

    private fun showFinalMessage() {
        finishLabel.visibility = VISIBLE
        finishLabel.scaleX = .75f
        finishLabel.scaleY = .75f
        finishLabel.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(650L).setListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) { onAllClosed() }
        }).start()
        sendAccessibilityEvent(AccessibilityEvent.TYPE_ANNOUNCEMENT)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
