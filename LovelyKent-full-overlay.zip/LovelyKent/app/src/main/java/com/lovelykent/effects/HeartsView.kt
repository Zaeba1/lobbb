package com.lovelykent.effects

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.sin
import kotlin.random.Random

/** Парящие сердечки, нарисованные программно (без эмодзи). Анимация идёт только пока view видим. */
class HeartsView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private class Heart(
        var x: Float, var y: Float, val size: Float, val speed: Float,
        val sway: Float, val phase: Float, val color: Int, val rot: Float,
    ) {
        var age = 0f
    }

    private val hearts = ArrayList<Heart>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val palette = intArrayOf(
        Color.rgb(255, 92, 147), Color.rgb(255, 143, 177), Color.rgb(255, 179, 203), Color.rgb(255, 63, 127),
    )
    private val density = resources.displayMetrics.density

    private var running = false
    private var lastMs = 0L
    private var spawnTimer = 0f

    /** Фоновые сердечки; выключаются в тёмных сценах. */
    var ambient = true
        set(value) {
            field = value
            if (value) startLoop()
        }

    fun burst(count: Int) {
        if (width == 0 || height == 0) return
        repeat(count) {
            hearts.add(
                Heart(
                    x = width * (0.15f + Random.nextFloat() * 0.7f),
                    y = height * (0.55f + Random.nextFloat() * 0.3f),
                    size = density * (16f + Random.nextFloat() * 30f),
                    speed = density * (90f + Random.nextFloat() * 140f),
                    sway = density * (8f + Random.nextFloat() * 20f),
                    phase = Random.nextFloat() * 6.28f,
                    color = palette[Random.nextInt(palette.size)],
                    rot = -20f + Random.nextFloat() * 40f,
                ),
            )
        }
        while (hearts.size > MAX_HEARTS) hearts.removeAt(0)
        startLoop()
    }

    private fun spawnAmbient() {
        hearts.add(
            Heart(
                x = width * Random.nextFloat(),
                y = height + density * 20f,
                size = density * (10f + Random.nextFloat() * 18f),
                speed = density * (28f + Random.nextFloat() * 36f),
                sway = density * (6f + Random.nextFloat() * 14f),
                phase = Random.nextFloat() * 6.28f,
                color = palette[Random.nextInt(palette.size)],
                rot = -15f + Random.nextFloat() * 30f,
            ),
        )
    }

    private fun startLoop() {
        if (running || !isShown) return
        running = true
        lastMs = SystemClock.uptimeMillis()
        postInvalidateOnAnimation()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startLoop()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) startLoop() else running = false
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastMs) / 1000f).coerceIn(0f, 0.05f)
        lastMs = now

        if (ambient && width > 0) {
            spawnTimer += dt
            if (spawnTimer > 0.7f && hearts.size < AMBIENT_LIMIT) {
                spawnTimer = 0f
                spawnAmbient()
            }
        }

        val it = hearts.iterator()
        while (it.hasNext()) {
            val h = it.next()
            h.age += dt
            h.y -= h.speed * dt
            if (h.y < -h.size * 2) {
                it.remove()
                continue
            }
            val cx = h.x + sin(h.age * 1.6f + h.phase) * h.sway
            val fade = (h.y / height).coerceIn(0f, 1f)
            paint.color = h.color
            paint.alpha = (60 + 150 * fade).toInt().coerceIn(0, 255)
            canvas.save()
            canvas.rotate(h.rot, cx, h.y)
            drawHeart(canvas, cx, h.y, h.size)
            canvas.restore()
        }

        if (running) {
            if (hearts.isEmpty() && !ambient) running = false else postInvalidateOnAnimation()
        }
    }

    private fun drawHeart(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        path.reset()
        path.moveTo(cx, cy + s * 0.35f)
        path.cubicTo(cx - s * 0.75f, cy - s * 0.05f, cx - s * 0.45f, cy - s * 0.65f, cx, cy - s * 0.25f)
        path.cubicTo(cx + s * 0.45f, cy - s * 0.65f, cx + s * 0.75f, cy - s * 0.05f, cx, cy + s * 0.35f)
        path.close()
        canvas.drawPath(path, paint)
    }

    private companion object {
        const val MAX_HEARTS = 60
        const val AMBIENT_LIMIT = 14
    }
}
