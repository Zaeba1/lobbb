package com.lovelykent

import android.os.Bundle
import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.view.MotionEvent
import android.view.View
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.lovelykent.databinding.ActivityMainBinding
import com.lovelykent.ui.StoryController

class MainActivity : AppCompatActivity() {

    private lateinit var story: StoryController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        story = StoryController(this, binding) { finish() }

        // Полноэкранный режим скрывает системные панели, не блокируя аварийный выход Android.
        applyImmersiveMode()
        tryStartPinnedMode()

        // Без окна подтверждения: кнопка «Назад» возвращает сцену назад,
        // а на корневом экране остаёмся в приложении.
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                story.goBack()
            }
        })
    }

    override fun onStart() {
        super.onStart()
        applyImmersiveMode()
        tryStartPinnedMode()
        story.onStart()
    }


    /**
     * Просим Android закрепить приложение. Для обычного приложения это будет
     * Screen Pinning; полноценный Lock Task без системного выхода требует,
     * чтобы устройство/приложение было разрешено администратором как kiosk.
     */
    private fun tryStartPinnedMode() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                if (am.lockTaskModeState == ActivityManager.LOCK_TASK_MODE_NONE) {
                    startLockTask()
                }
            } else {
                @Suppress("DEPRECATION")
                startLockTask()
            }
        } catch (_: SecurityException) {
            // Если устройство запрещает закрепление, приложение продолжает работать
            // в полноэкранном режиме без аварийного завершения.
        } catch (_: IllegalStateException) {
            // Некоторые прошивки не разрешают закрепление в текущем состоянии.
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) applyImmersiveMode()
    }

    @Suppress("DEPRECATION")
    private fun applyImmersiveMode() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
    }

    override fun onStop() {
        story.onStop()
        super.onStop()
    }

    override fun onDestroy() {
        story.release()
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) story.onGlobalTouch(ev.rawX, ev.rawY)
        return super.dispatchTouchEvent(ev)
    }
}
