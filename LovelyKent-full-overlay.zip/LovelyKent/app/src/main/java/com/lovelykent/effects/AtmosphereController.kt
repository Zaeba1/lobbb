package com.lovelykent.effects

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.graphics.Typeface
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import com.lovelykent.R
import com.lovelykent.databinding.ActivityMainBinding

/** Плавно переводит весь интерфейс от романтики (0) к хоррору (1). */
class AtmosphereController(
    private val activity: Activity,
    private val b: ActivityMainBinding,
) {
    private val argb = ArgbEvaluator()
    private var shown = 0f
    private var animator: ValueAnimator? = null
    private var overlayEnabled = true
    private var darkButtons = false
    private var monoFont = false

    private val plum = ContextCompat.getColor(activity, R.color.plum)
    private val plumSoft = ContextCompat.getColor(activity, R.color.plum_soft)
    private val light = ContextCompat.getColor(activity, R.color.off_white)
    private val blood = ContextCompat.getColor(activity, R.color.blood)
    private val topColor = ContextCompat.getColor(activity, R.color.bg_top)
    private val bottomColor = ContextCompat.getColor(activity, R.color.bg_bottom)
    private val night = ContextCompat.getColor(activity, R.color.night)

    /** @param morphCat true — постепенно подмешивать страшного кота поверх текущего. */
    fun setIntensity(target: Float, morphCat: Boolean, durationMs: Long = 600L) {
        animator?.cancel()
        overlayEnabled = morphCat
        animator = ValueAnimator.ofFloat(shown, target).apply {
            duration = durationMs
            addUpdateListener { render(it.animatedValue as Float) }
            start()
        }
    }

    fun release() {
        animator?.cancel()
        animator = null
    }

    private fun mix(from: Int, to: Int, t: Float): Int = argb.evaluate(t.coerceIn(0f, 1f), from, to) as Int

    @Suppress("DEPRECATION")
    private fun render(v: Float) {
        shown = v
        b.bgHorror.alpha = (v * 1.15f).coerceIn(0f, 1f)
        b.horrorTexture.alpha = (v * 0.9f).coerceIn(0f, 1f)
        b.decoHearts.alpha = (1f - v * 1.4f).coerceIn(0f, 1f)
        b.hearts.ambient = v < 0.3f
        b.catOverlay.alpha = if (overlayEnabled) ((v - 0.08f) / 0.55f).coerceIn(0f, 0.9f) else 0f

        val tt = (v * 1.5f).coerceIn(0f, 1f)
        val redT = ((v - 0.85f) / 0.15f).coerceIn(0f, 1f)
        b.title.setTextColor(mix(mix(plum, light, tt), blood, redT))
        b.subtitle.setTextColor(mix(plumSoft, light, tt))

        val dark = v >= 0.45f
        if (dark != darkButtons) {
            darkButtons = dark
            b.btnPrimary.setBackgroundResource(if (dark) R.drawable.btn_primary_dark else R.drawable.btn_primary)
            b.btnSecondary.setBackgroundResource(if (dark) R.drawable.btn_secondary_dark else R.drawable.btn_secondary)
            b.btnSecondary.setTextColor(if (dark) light else plum)
        }
        val mono = v >= 0.6f
        if (mono != monoFont) {
            monoFont = mono
            val tf = if (mono) Typeface.MONOSPACE else Typeface.create("sans-serif-medium", Typeface.NORMAL)
            b.title.typeface = tf
        }

        val window = activity.window
        window.statusBarColor = mix(topColor, night, v * 1.2f)
        window.navigationBarColor = mix(bottomColor, night, v * 1.2f)
        WindowCompat.getInsetsController(window, b.root).isAppearanceLightStatusBars = v < 0.5f
    }
}
