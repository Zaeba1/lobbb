package com.lovelykent.ui

import android.graphics.Rect
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.hypot
import kotlin.math.min
import kotlin.random.Random

/**
 * Убегающая кнопка. Двигается только сама кнопка (translationX/Y), разметка не трогается.
 * Все прямоугольники — в экранных координатах.
 */
class RunawayButtonController(
    private val stage: View,
    private val button: View,
    private val obstacles: () -> List<Rect>,
    private val onAttempt: (attempts: Int) -> Unit,
) {
    var attempts = 0
        private set

    /** Включён только на первом экране. */
    var enabled = false

    private val canFlee get() = enabled && attempts < MAX_FLEES
    private val density = stage.resources.displayMetrics.density
    private var lastW = 0
    private var lastH = 0

    init {
        stage.addOnLayoutChangeListener { _, l, t, r, b, _, _, _, _ ->
            val w = r - l
            val h = b - t
            if (w != lastW || h != lastH) {
                lastW = w
                lastH = h
                home() // размер/ориентация изменились — возвращаем кнопку на место
            }
        }
        button.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN && canFlee) {
                flee()
                true
            } else {
                false
            }
        }
        button.setOnHoverListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_HOVER_ENTER && canFlee) {
                flee()
                true
            } else {
                false
            }
        }
    }

    /** Касание рядом с кнопкой (но не по ней) тоже спугивает её. */
    fun onGlobalTouch(x: Float, y: Float) {
        if (!canFlee || button.visibility != View.VISIBLE) return
        val r = screenRect(button)
        val near = Rect(r).apply { inset(-(24 * density).toInt(), -(24 * density).toInt()) }
        if (near.contains(x.toInt(), y.toInt()) && !r.contains(x.toInt(), y.toInt())) flee()
    }

    fun reset() {
        attempts = 0
        home()
    }

    private fun home() {
        button.animate().cancel()
        button.translationX = 0f
        button.translationY = 0f
    }

    private fun flee() {
        attempts++
        val target = pickTarget()
        if (target == null) {
            home()
        } else {
            val cur = screenRect(button)
            button.animate().cancel()
            button.animate()
                .translationX(button.translationX + (target.left - cur.left))
                .translationY(button.translationY + (target.top - cur.top))
                .setDuration(MOVE_MS)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
        onAttempt(attempts)
    }

    private fun pickTarget(): Rect? {
        val pad = (8 * density).toInt()
        val arena = screenRect(stage).apply { inset(pad, pad) }
        val cur = screenRect(button)
        val bw = cur.width()
        val bh = cur.height()
        if (arena.width() < bw || arena.height() < bh) return null

        val gap = (12 * density).toInt()
        val blocked = obstacles().map { Rect(it).apply { inset(-gap, -gap) } }
        val minDist = min(arena.width(), arena.height()) * 0.3f
        var best: Rect? = null
        var bestDist = -1f
        repeat(TRIES) {
            val l = arena.left + Random.nextInt(arena.width() - bw + 1)
            val t = arena.top + Random.nextInt(arena.height() - bh + 1)
            val c = Rect(l, t, l + bw, t + bh)
            if (blocked.none { Rect.intersects(it, c) }) {
                val d = hypot((c.centerX() - cur.centerX()).toFloat(), (c.centerY() - cur.centerY()).toFloat())
                if (d >= minDist) return c
                if (d > bestDist) {
                    best = c
                    bestDist = d
                }
            }
        }
        return best
    }

    companion object {
        const val MAX_FLEES = 9
        private const val TRIES = 160
        private const val MOVE_MS = 210L

        fun screenRect(v: View): Rect {
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            return Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
        }
    }
}
