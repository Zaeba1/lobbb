package com.lovelykent.scenario

import com.lovelykent.R

/** Граф сценария. Чтобы добавить экран: новый SceneId + запись здесь. */
object Scenario {

    val start = SceneId.ASK

    private fun go(id: SceneId) = Target.Go(id)

    private val scenes: Map<SceneId, Scene> = listOf(
        Scene(
            SceneId.ASK, R.string.ask_title, null, CatMood.HAPPY, 0f,
            listOf(
                Choice(R.string.btn_yes, go(SceneId.YES)),
                Choice(R.string.btn_no_0, go(SceneId.SURE)),
            ),
        ),
        Scene(
            SceneId.YES, R.string.yes_title, R.string.yes_sub, CatMood.LOVE, 0f,
            listOf(
                Choice(R.string.btn_again, go(SceneId.ASK)),
                Choice(R.string.btn_bye, Target.Exit),
            ),
            heartsBurst = true,
        ),
        Scene(
            SceneId.SURE, R.string.sure_title, R.string.sure_sub, CatMood.SAD, 0.12f,
            listOf(
                Choice(R.string.btn_changed, go(SceneId.YES)),
                Choice(R.string.btn_sure_yes, go(SceneId.HURT)),
            ),
        ),
        Scene(
            SceneId.HURT, R.string.hurt_title, R.string.hurt_sub, CatMood.SAD, 0.28f,
            listOf(
                Choice(R.string.btn_sorry, go(SceneId.YES)),
                Choice(R.string.btn_still_no, go(SceneId.COLD)),
            ),
        ),
        Scene(
            SceneId.COLD, R.string.cold_title, R.string.cold_sub, CatMood.SAD, 0.5f,
            listOf(
                Choice(R.string.btn_what, go(SceneId.WATCH)),
                Choice(R.string.btn_go, go(SceneId.WATCH)),
            ),
            glitchOnEnter = true,
        ),
        Scene(
            SceneId.WATCH, R.string.watch_title, R.string.watch_sub, CatMood.SCARY, 0.7f,
            listOf(
                Choice(R.string.btn_dont_scare, go(SceneId.HORROR)),
                Choice(R.string.btn_ignore, go(SceneId.HORROR)),
            ),
            glitchOnEnter = true,
        ),
        // Автоматическая сцена: ведёт HorrorDirector, кнопок нет.
        Scene(
            SceneId.HORROR, R.string.horror_1, null, CatMood.SCARY, 0.85f,
            emptyList(),
        ),
        // Кнопок нет сразу: финал держит напряжение, Back всегда работает,
        // а через 30 секунд появляется отдельная кнопка выхода (см. StoryController).
        Scene(
            SceneId.FINALE, R.string.final_title, R.string.final_sub, CatMood.FINAL, 1f,
            emptyList(),
            glitchOnEnter = true,
        ),
    ).associateBy { it.id }

    fun scene(id: SceneId): Scene = scenes.getValue(id)
}
