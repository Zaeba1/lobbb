# LovelyKent

Android application in Kotlin (`com.lovelykent`). Existing romantic/horror scenes, custom drawable assets, runaway “Нет” button, atmosphere effects and glitch view are retained.

## Build

Requires JDK 17 and Gradle 8.9 (Android Gradle Plugin 8.7.3). Run from the project root:

```sh
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

GitHub Actions workflow `.github/workflows/android.yml` builds `assembleDebug` and uploads the APK as the `LovelyKent-APK` artifact containing `LovelyKent.apk`.

## Finale overlay

The horror branch ends with ten custom, in-app retro error windows. Each “ЛЮБЛЮ ТЕБЯ” button dismisses its own window; after all ten are dismissed, the finale message appears. The overlay is not a real OS dialog and intentionally does not disable Android Back/navigation or trap the user in the app.


## Fullscreen / exit restriction

The main activity reapplies immersive fullscreen when it regains focus and requests Android screen pinning (`startLockTask`) without showing an in-app confirmation dialog. On standard personal devices Android may show its own pinning guidance and users can still unpin using system controls. Fully managed kiosk behavior requires the app to be allowlisted by a Device Owner / Android Enterprise administrator; an ordinary app cannot silently block Home, Recents, or emergency/system navigation.
